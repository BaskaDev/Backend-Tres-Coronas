export interface Bar{
    bar: any;
    idBar:number;
    nameBar:string;
    addressBar:string;
    locallyBar:string;
}