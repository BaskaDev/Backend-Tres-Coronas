export interface Product {
    id_product:number;
    name_product:string;
}