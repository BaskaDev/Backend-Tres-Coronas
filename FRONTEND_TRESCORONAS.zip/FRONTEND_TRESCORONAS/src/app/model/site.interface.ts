import { Bar } from "./bar.interface";

export interface Site {
    idSite:number;
    bar: Bar;
}